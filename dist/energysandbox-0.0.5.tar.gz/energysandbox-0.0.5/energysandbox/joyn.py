def addTwoNumbers(a, b):
    return a + b

